<!doctype html>
<html>
<head>
<title> Add Data </title>
</head>
<body>
<?php
include_once("connection.php");
$productid=mysqli_real_escape_string($mysqli, $_POST['product_id']);

$productname=mysqli_real_escape_string($mysqli, $_POST['product_name']);

$quantityavailable=mysqli_real_escape_string($mysqli, $_POST['quantity_available']);

$quantityadded=mysqli_real_escape_string($mysqli, $_POST['quantity_added']);

$purches=mysqli_real_escape_string($mysqli, $_POST['purches']);
$productdate=mysqli_real_escape_string($mysqli, $_POST['product_date']);

$result=mysqli_query($mysqli,"update stock set product_id product_name='$productname',quantity_available='$quantityavailable',quantity_added='$quantity_added',purches='$purches',product_date='$product_date' where product_id='$productid');");

?>

</body>
</html>
