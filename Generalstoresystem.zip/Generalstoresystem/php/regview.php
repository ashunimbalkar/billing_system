<html>
<head>
<title>
View registration deatils
</title>
</head>
<body>
<table border="1">
<caption>registration Details</caption>
<th>
<td>user name</td>
<td>user password</td>
<td>user mail</td>
<td>user phone</td>
</th>
<tr>
<td>ashwini</td>
<td>123</td>
<td>ashwiniwagmode6397@gmail.com</td>
<td>9078563412</td>
</tr>
</table>
</body>
</html>