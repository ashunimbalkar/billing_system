<html>
<head>
<title>
View registration deatils
</title>
</head>
<body>
<table border="1">
<?php
include_once('connection.php');
$result=mysqli_query($mysqli,"select * from registration");
while($res=mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $res['username']. "</td>";
echo "<td>" . $res['userpassword']. "</td>";
echo  "<td>" .$res['usermail'] ."</td>";
echo  "<td>" . $res['userphone'] . "</td>";
echo  "<td>" . $res['useraddress'] . "</td>";
echo "</tr>";
}
?>
</table>
</body>
</html>