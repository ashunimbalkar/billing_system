<?php


include_once('connection.php');

$password= mysqli_real_escape_string($mysqli, $_POST['userpassword']);

$email= mysqli_real_escape_string($mysqli, $_POST['usermail']);

$phone= mysqli_real_escape_string($mysqli, $_POST['userphone']);

$name= mysqli_real_escape_string($mysqli, $_POST['username']);

$result= mysqli_query($mysqli,"update registration set userpassword='$password', usermail='$email', userphone='$phone'  where username='$name' " );

?>
