<html>
<head>
<title>
View  invoice deatils
</title>
</head>
<body>
<table border="1">
<caption>Invoice</caption>
<tr>
<th>bill_no</th>
<th>bill_date</th>
<th>product_id</th>
<th>product_name</th>
<th>quantity</th>
<th>per_unit_price</th>
<th>discount</th>

<th>total_price</th>
<th>discount_amount</th>

<th>tax</th>
<th>grant_total</th>

</tr>
<?php
include_once('connection.php');
$result=mysqli_query($mysqli,"select * from invoice");
while($res=mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $res['bill_no']. "</td>";
echo "<td>" . $res['bill_date']. "</td>";
echo  "<td>" .$res['product_id'] ."</td>";
echo  "<td>" . $res['product_name'] . "</td>";
echo  "<td>" . $res['quantity'] . "</td>";
echo  "<td>" . $res['per_unit_price'] . "</td>";
echo  "<td>" . $res['discount'] . "</td>";
echo  "<td>" . $res['total_price'] . "</td>";
echo  "<td>" . $res['discount_amount'] . "</td>";
echo  "<td>" . $res['tax'] . "</td>";
echo  "<td>" . $res['grant_total'] . "</td>";
echo "</tr>";
}
?>
</table>
</body>
</html>