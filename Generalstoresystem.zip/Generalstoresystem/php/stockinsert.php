<!doctype html>
<html>
<head>
<title> Add Data </title>
</head>
<body>
<?php
include_once("connection.php");
$productid=mysqli_real_escape_string($mysqli, $_POST['product_id']);

$productname=mysqli_real_escape_string($mysqli, $_POST['product_name']);

$quantityavailable=mysqli_real_escape_string($mysqli, $_POST['quantity_available']);

$quantityadded=mysqli_real_escape_string($mysqli, $_POST['quantity_added']);

$purches=mysqli_real_escape_string($mysqli, $_POST['purches']);
$productdate=mysqli_real_escape_string($mysqli, $_POST['product_date']);

$result=mysqli_query($mysqli,"insert into stock(product_id,product_name,quantity_available,quantity_added,purches,product_date)values('$productid','$productname','$quantityavailable','$quantityadded','$purches','$productdate');");
?>
</body>
</html>
