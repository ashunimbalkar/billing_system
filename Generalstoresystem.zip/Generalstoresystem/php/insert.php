<!doctype html>
<html>
<head>
<title> Add Data </title>
</head>
<body>
<?php
include_once("connection.php");
$name=mysqli_real_escape_string($mysqli, $_POST['username']);

$password=mysqli_real_escape_string($mysqli, $_POST['userpassword']);

$email=mysqli_real_escape_string($mysqli, $_POST['usermail']);

$phone=mysqli_real_escape_string($mysqli, $_POST['userphone']);

$address=mysqli_real_escape_string($mysqli, $_POST['useraddress']);

$result=mysqli_query($mysqli,"insert into registration(username, userpassword,usermail,userphone,useraddress) values('$name','$password','$email', '$phone','$address' )");



?>

</body>
</html>
