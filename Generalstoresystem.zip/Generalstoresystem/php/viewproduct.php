<html>
<head>
<title>
View product details
</title>
</head>
<body>
<table border="1">
<caption>product update</caption>
<tr>
<th>product_id</th>
<th>product_name</th>
<th>product_available</th>
<th>product_price</th>
<th>product_discount</th>
<th>product_taxname</th>
<th>product_taxvalue</th>
</tr>
<?php
include_once('connection.php');
$result=mysqli_query($mysqli,"select * from product_update");
while($res=mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $res['product_id']. "</td>";
echo "<td>" . $res['product_name']. "</td>";
echo  "<td>" .$res['product_available'] ."</td>";
echo  "<td>" . $res['product_price'] . "</td>";
echo  "<td>" . $res['product_discount'] . "</td>";
echo  "<td>" . $res['product_taxname'] . "</td>";
echo  "<td>" . $res['product_taxvalue'] . "</td>";
echo "</tr>";
}
?>
</table>
</body>
</html>