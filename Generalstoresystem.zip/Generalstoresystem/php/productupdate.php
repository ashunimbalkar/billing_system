<!doctype html>
<html>
<head>
<title> Add Data </title>
</head>
<body>
<?php
include_once("connection.php");
$productid=mysqli_real_escape_string($mysqli, $_POST['product_id']);

$productname=mysqli_real_escape_string($mysqli, $_POST['product_name']);

$productavailable=mysqli_real_escape_string($mysqli, $_POST['product_available']);

$productprice=mysqli_real_escape_string($mysqli, $_POST['product_price']);

$productdiscount=mysqli_real_escape_string($mysqli, $_POST[product_discount']);

$producttaxname=mysqli_real_escape_string($mysqli, $_POST['product_taxname']);

$producttaxvalue=mysqli_real_escape_string($mysqli, $_POST['product_taxvalue']);

$productperunitprice=mysqli_real_escape_string($mysqli, $_POST['product_per_unit_price']);
$productdate=mysqli_real_escape_string($mysqli, $_POST['product_date']);
$productexpirydate=mysqli_real_escape_string($mysqli, $_POST['product_expiry_date']);

$result=mysqli_query($mysqli,"update product_update set product_name='$productname',product_available='$productavailable',product_price='$productprice',product_discount='$productdiscount',product_taxname='$producttaxname',product_taxvalue='$producttaxvalue',product_per_unit_price='$productperunitprice',product_date='$productdate',product_expiry_date='$productexpirydate' where product_id='$productid')");

?>

</body>
</html>
