<?php
include_once("connection.php");
$name=mysqli_real_escape_string($mysqli, $_POST['username']);

$result=mysqli_query($mysqli," delete from registration where username='$name' ");
header('Location:select.php');
?>