<!doctype html>
<html>
<head>
<title> Add Data </title>
</head>
<body>
<?php
include_once("connection.php");
$productid=mysqli_real_escape_string($mysqli, $_POST['product_id']);

$productname=mysqli_real_escape_string($mysqli, $_POST['product_name']);

$productavailable=mysqli_real_escape_string($mysqli, $_POST['product_available']);

$productprice=mysqli_real_escape_string($mysqli, $_POST['product_price']);

$productdiscount=mysqli_real_escape_string($mysqli, $_POST[product_discount']);

$producttaxvalue=mysqli_real_escape_string($mysqli, $_POST['product_taxvalue']);

$productperunitprice=mysqli_real_escape_string($mysqli, $_POST['product_per_unit_price']);

$productdate=mysqli_real_escape_string($mysqli, $_POST['product_date']);

$productexpirydate=mysqli_real_escape_string($mysqli, $_POST['product_expiry_date']);

$result=mysqli_query($mysqli," insert into product_update(product_id,product_name,product_available,product_price,product_discount,product_taxname,product_taxvalue,product_per_unit_price,product_date,product_expiry_date)values('$productid','$productname','$productavailable','$productprice','$productdiscount','$producttaxname','$producttaxvalue','$productperunitprice','$productdate','$productexpirydate');");

?>

</body>
</html>
