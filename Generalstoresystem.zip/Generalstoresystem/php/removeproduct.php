<?php
include_once("connection.php");
$name=mysqli_real_escape_string($mysqli, $_POST['username']);

$result=mysqli_query($mysqli," delete from product_update where username='$name' ");
header('Location:viewproduct.php');
?>