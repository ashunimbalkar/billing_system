<!doctype html>
<html>
<head>
<title> Add Data </title>
</head>
<body>
<?php
include_once("connection.php");
$cashierid=mysqli_real_escape_string($mysqli, $_POST['cashier_id']);

$cashiername=mysqli_real_escape_string($mysqli, $_POST['cashier_name']);

$mobileno=mysqli_real_escape_string($mysqli, $_POST['mobile_no']);

$address=mysqli_real_escape_string($mysqli, $_POST['address']);

$email=mysqli_real_escape_string($mysqli, $_POST['email']);
$password=mysqli_real_escape_string($mysqli, $_POST['password']);

$gender=mysqli_real_escape_string($mysqli, $_POST['gender']);

$city=mysqli_real_escape_string($mysqli, $_POST['city']);
$country=mysqli_real_escape_string($mysqli, $_POST['country']);

$state=mysqli_real_escape_string($mysqli, $_POST['state']);

$date=mysqli_real_escape_string($mysqli, $_POST['date']);
$birthdate=mysqli_real_escape_string($mysqli, $_POST['birthdate']);

$age=mysqli_real_escape_string($mysqli, $_POST['age']);

$experience=mysqli_real_escape_string($mysqli, $_POST['experience']);
$user=mysqli_real_escape_string($mysqli, $_POST['user']);

$result=mysqli_query($mysqli,"insert into cashier_update(cashier_id,cashier_name,mobile_no,address,email,password,gender,city,country,state,date,birthdate,age,experience,user)values('$cashierid','$cashiername','$mobileno','$address','$email','$password','$gender','$city','$country','$state','$date','$birthdate','$age','$experience','$user');");
?>

</body>
</html>
