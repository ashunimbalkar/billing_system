<!doctype html>
<html>
<head>
<title> Add Data </title>
</head>
<body>
<?php
include_once("connection.php");
$billno=mysqli_real_escape_string($mysqli, $_POST['bill_no']);

$billdate=mysqli_real_escape_string($mysqli, $_POST['bill_date']);

$productid=mysqli_real_escape_string($mysqli, $_POST['product_id']);

$productname=mysqli_real_escape_string($mysqli, $_POST['product_name']);

$quantity=mysqli_real_escape_string($mysqli, $_POST['quantity']);
$perunitprice=mysqli_real_escape_string($mysqli, $_POST[' per_unit_price']);

$discount=mysqli_real_escape_string($mysqli, $_POST['discount ']);

$totalprice=mysqli_real_escape_string($mysqli, $_POST['total_price']);
$discountamount=mysqli_real_escape_string($mysqli, $_POST['discount_amount']);

$tax=mysqli_real_escape_string($mysqli, $_POST['tax']);

$granttotal=mysqli_real_escape_string($mysqli, $_POST['grant_total_price']);

$result=mysqli_query($mysqli,"insert into invoice(bill_no,bill_date,product_id,product_name,quantity,per_unit_price,discount,total_price,discount_amount,tax,grant_total_price)values('$billno','$billdate','$productid','$productname','$quantity','$perunitprice','$discount','$totalprice','$discountamount','$tax','$granttotal');");



?>

</body>
</html>
