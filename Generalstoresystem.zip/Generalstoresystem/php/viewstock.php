<html>
<head>
<title>
View stock details
</title>
</head>
<body>
<table border="1">
<caption>stock</caption>
<tr>
<th>product_id</th>
<th>product_name</th>
<th>quantity_available</th>
<th>quantity_added</th>
<th>purches</th>
<th>product_date</th>
</tr>
<?php
include_once('connection.php');
$result=mysqli_query($mysqli,"select * from stock");
while($res=mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $res['productid']. "</td>";
echo "<td>" . $res['productname']. "</td>";
echo  "<td>" .$res['quantityavailable'] ."</td>";
echo  "<td>" . $res['quantityadded'] . "</td>";
echo  "<td>" . $res['purches'] . "</td>";
echo  "<td>" . $res['productdate'] . "</td>";
echo "</tr>";
}
?>
</table>
</body>
</html>