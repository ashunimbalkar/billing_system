<html>
<head>
<title>
View cashier deatils
</title>
</head>
<body>
<table border="1">
<caption>view cashier</caption>
<tr>
<th>cashier_id</th>
<th>cashier_name</th>
<th>mobile_no</th>
<th>address</th>
<th>email</th>
<th>password</th>
<th>gender</th>
<th>city</th>
<th>country</th>
<th>state</th>
<th>date</th>
<th>birthdate</th>
<th>age</th>
<th>experience</th>
<th>user</th>
</tr>
<?php
include_once('connection.php');
$result=mysqli_query($mysqli,"select * from cashier_update");
while($res=mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $res['cashierid']. "</td>";
echo "<td>" . $res['cashiername']. "</td>";
echo  "<td>" .$res['mobileno'] ."</td>";
echo  "<td>" . $res['address'] . "</td>";
echo  "<td>" . $res['email'] . "</td>";
echo  "<td>" . $res['password'] . "</td>";
echo  "<td>" . $res['gender'] . "</td>";
echo  "<td>" . $res['city'] . "</td>";
echo  "<td>" . $res['country'] . "</td>";
echo  "<td>" . $res['state'] . "</td>";

echo  "<td>" . $res['date'] . "</td>";
echo  "<td>" . $res['birthdate'] . "</td>";
echo  "<td>" . $res['age'] . "</td>";

echo  "<td>" . $res['experience'] . "</td>";
echo  "<td>" . $res['user'] . "</td>";
echo "</tr>";
}
?>
</table>
</body>
</html>